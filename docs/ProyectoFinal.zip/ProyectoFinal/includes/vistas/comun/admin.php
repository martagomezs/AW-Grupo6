
<header>
    <a href="login.php" class="logo"><img src="img/utils/logo.png" name="logo" width="75"></a>

    <div class="menu">
        <input type="button" onclick="window.location.href = 'adminCancion.php';" name="Canciones" value="Cancion" >

        <input type="button" onclick="window.location.href = 'adminVinilo.php';" name="Vinilos" value="Vinilo" >

        <input type="button" onclick="window.location.href = 'adminArtista.php';" name="Artistas" value="Artista" >

        <input type="button" onclick="window.location.href = 'adminEvento.php';" name="Eventos" value="Evento" >

        <input type="button" onclick="window.location.href = 'adminUsuario.php';" name="Usuarios" value="Usuario" >
    </div>

    <div class="icons">
        <a href="login.php"><img src="img/utils/user.png" width="50"></a>
    </div>
</header>